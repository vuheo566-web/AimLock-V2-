# AIMLOCK V2 FREE — Android APK

Repo-ready Android WebView app based on the supplied UI reference.

## Build on GitHub
1. Create a new GitHub repository.
2. Upload all files/folders from this project.
3. Commit to `main`.
4. Open **Actions** → **Build AIMLOCK V2 Free APK**.
5. Run **Build workflow** if needed.
6. Download the `AIMLOCK-V2-FREE-APK` artifact.

## Included
- No account login screen; a valid Basic/Premium key is required before the main menu.
- AIMLOCK-style red/black UI.
- ON/OFF controls.
- REG FILES / BOOST RAM / HEADLOCK / FIX RESPONSE UI.
- BOOST RAM visual code/progress for ~2 seconds.
- Basic/Premium key countdown logic from the HTML package.
- Free Fire / FF Max launch buttons using Android intents when those apps are installed.

This project is a UI/local-state app. It does not modify game memory, inject into game processes, or bypass anti-cheat.

## Key gate
The app starts on a key-entry screen. It detects whether the entered key is BASIC (50 days) or PREMIUM (500 days), then unlocks the main menu. Invalid/expired keys stay on the key screen.
